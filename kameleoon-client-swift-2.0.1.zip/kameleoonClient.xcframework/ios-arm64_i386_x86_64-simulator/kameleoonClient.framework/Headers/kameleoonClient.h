//
//  kameleoonClient.h
//  kameleoonClient
//
//  Created by Vincent Bernardi on 17/05/2018.
//  Copyright © 2018 Kameleoon. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ssx.
FOUNDATION_EXPORT double ssxVersionNumber;

//! Project version string for ssx.
FOUNDATION_EXPORT const unsigned char ssxVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <kameleoonClient/PublicHeader.h>

// #import <kameleoonClient/PublicHeader.h>
